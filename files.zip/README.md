# MD5 Email Hash Generator

**Author:** Sara Memon

A simple website to generate MD5 hashes for email addresses.  
- Paste one email per line.
- See hashed output instantly.
- Copy results to clipboard with a button.

## How to Use

1. Open `index.html` in your browser.
2. Enter emails, one per line.
3. Copy results!

## Credits

Uses [CryptoJS](https://github.com/brix/crypto-js) for MD5 hashing.