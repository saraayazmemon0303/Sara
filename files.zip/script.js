const emailInput = document.getElementById("emailInput");
const output = document.getElementById("output");
const copyMessage = document.getElementById("copyMessage");

emailInput.addEventListener("input", () => {
  const lines = emailInput.value.split("\n");
  let results = [];

  for (let i = 0; i < lines.length; i++) {
    let line = lines[i].trim();
    if (!line) continue;

    let hash = CryptoJS.MD5(line.toLowerCase()).toString();
    if (/\s/.test(line)) {
      results.push(`${hash}    ⚠️ Line ${i + 1} has space(s)`);
    } else {
      results.push(hash);
    }
  }

  output.textContent = results.join("\n");
  copyMessage.textContent = "";
});

function copyToClipboard() {
  navigator.clipboard.writeText(output.textContent)
    .then(() => {
      copyMessage.textContent = "Copied to clipboard!";
    })
    .catch(() => {
      copyMessage.textContent = "Failed to copy!";
    });
}